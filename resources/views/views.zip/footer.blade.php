  
    <!-- #/ container -->
</div>
  
<!--**********************************
    Footer end
***********************************-->
</div>
<!--**********************************
Main wrapper end
***********************************-->

<!--**********************************
Scripts
***********************************-->
<script src="{{url('public/assets/plugins/common/common.min.js')}}"></script>
<script src="{{url('public/assets/js/custom.min.js')}}"></script>
<script src="{{url('public/assets/js/settings.js')}}"></script>
<script src="{{url('public/assets/js/gleek.js')}}"></script>
<script src="{{url('public/assets/js/styleSwitcher.js')}}"></script>

<!-- Chartjs -->
<script src="{{url('public/assets/plugins/chart.js/Chart.bundle.min.js')}}"></script>
<!-- Circle progress -->
<script src="{{url('public/assets/plugins/circle-progress/circle-progress.min.js')}}"></script>
<!-- Datamap -->
<script src="{{url('public/assets/plugins/d3v3/index.js')}}"></script>
<script src="{{url('public/assets/plugins/topojson/topojson.min.js')}}"></script>
<script src="{{url('public/assets/plugins/datamaps/datamaps.world.min.js')}}"></script>
<!-- Morrisjs -->
<script src="{{url('public/assets/plugins/raphael/raphael.min.js')}}"></script>
<script src="{{url('public/assets/plugins/morris/morris.min.js')}}"></script>
<!-- Pignose Calender -->
<script src="{{url('public/assets/plugins/moment/moment.min.js')}}"></script>
<script src="{{url('public/assets/plugins/pg-calendar/js/pignose.calendar.min.js')}}"></script>
<!-- ChartistJS -->
<script src="{{url('public/assets/plugins/chartist/js/chartist.min.js')}}"></script>
<script src="{{url('public/assets/plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js')}}"></script>

    <script src="{{url('public/assets/plugins/tables/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{url('public/assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js')}}"></script>
    <script src="{{url('public/assets/plugins/tables/js/datatable-init/datatable-basic.min.js')}}"></script>
    


<script src="{{url('public/assets/js/dashboard/dashboard-1.js')}}"></script>
{{-- for toogle switch --}}
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
{{-- for advertise show --}}
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
  
  
